// stage.js

var stageState;

(function(){

	// Board stuff
	var middleX;
	var middleY;
	var bottomY;
	var boards;
	var boardsTexts;
	var boardLeftUp;
	var boardRightUp;
	var boardLeftDown;
	var boardRightDown;

	// gui
	var groupBoardTexts;

	// card control
	var timeToSpeedy;
	var timeoutSpeedy;

	function setBoards() {

		boards = [];
		boardsTexts = [];

		middleX = game.world.centerX;
		middleY = game.world.centerY;
		bottomY = game.world.height * 0.55;

		boards[0] = game.add.sprite(0, 0, 'r');
		boards[1] = game.add.sprite(middleX, 0, 'g');
		switch(stage.game.boardCount) {
			case 2:
				boards[0].scale.set(middleX, game.world.height);
				boards[1].scale.set(middleX, game.world.height);
				break;
			case 3:
				boards[0].scale.set(game.world.height, bottomY);
				boards[1].scale.set(middleX, bottomY);
				boards[2] = game.add.sprite(0, bottomY, 'b');
				boards[2].scale.set(game.world.width, bottomY);
				break;
			case 4:
				boards[0].scale.set(middleX, middleY);
				boards[1].scale.set(middleX, middleY);
				boards[2] = game.add.sprite(0, middleY, 'b');
				boards[2].scale.set(middleX, middleY);
				boards[3] = game.add.sprite(middleX, middleY, 'y');
				boards[3].scale.set(middleX, middleY);
				break;			
		}

		for(var i = 0; i < boards.length; i++){
			boards[i].text = game.add.text(boards[i].x + boards[i].width / 2, boards[i].y + boards[i].height / 2, '', {
		        font: "125px Arial",
		        fill: "#ffffff",
		        align: "center"
		    });
		    boards[i].text.anchor.set(0.5, 0.5);
		    boardsTexts.push(boards[i].text);
		}
	}

	// handling socket

	function doSpeedy(){
		if(config.isTest){
			_.each(stage.game.boards, function(board){
				board.current = _.random(0, 9);
			});
			handleSpeedy({ boards: stage.game.boards });
			return;
		}
		socket.emit('speed.stage.speedy');
	}

	function handleStart(){
		doSpeedy();
	}

	function handleSpeedy(data){
		stage.game.boards = data.boards;
		var i = 0;
		_.forEach(boardsTexts, function(item){
			item.angle = 0;
			item.setText('Spdy');
			i++
		});
		var shuffled = _.shuffle(boardsTexts);
		TweenMax.staggerTo(shuffled, 1, { angle:360, ease: Back.easeInOut }, 0.1, function(){
			for(var i = 0; i < stage.game.boardCount; i++){
				boards[i].text.setText(stage.game.boards[i].current);
			}
			if(config.isTest){
				timeToSpeedy = 3000;
				return;
			}
			clearTimeout(timeoutSpeedy);
			timeoutSpeedy = setTimeout(doSpeedy, data.timeToSpeedy);
			socket.emit('speed.stage.play');
		});
	}

	function handleCard(data){
		boards[data.boardId].text.setText(data.card);
		clearTimeout(timeoutSpeedy);
		timeoutSpeedy = setTimeout(doSpeedy, data.timeToSpeedy);
	}

	stageState = {

		preload: function(){
			game.load.image('r', 'assets/sprites/r.jpg');
			game.load.image('b', 'assets/sprites/b.jpg');
			game.load.image('g', 'assets/sprites/g.jpg');
			game.load.image('y', 'assets/sprites/y.jpg');
		},

		create: function(){
			setBoards();
			
			socket.on('speed.stage.start', handleStart);
			socket.on('speed.stage.speedy', handleSpeedy);
			socket.on('speed.stage.card', handleCard);
			
			if(config.isTest){
				handleStart();
				return;
			}
			socket.emit('speed.stage.loaded');
		},

		update: function(){

		},

		render: function(){

		},

	}

})();