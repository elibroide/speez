// main.js

var mainState;
var graphics;

(function(){
	
	// general
	var isReady;

	// gui
	var buttons;
	var textStatus;
	var btnJoinStage;
	var btnBecomeStage;
	var btnTestPlayer;
	var btnTestStage;
	var btnReady;
	var tbxStageId;

	var btnScale;

	var counter = 0;

	// gui draw

	// debug
	var textLatency;

	function drawGui(){

		graphics = game.add.graphics();
		graphics.beginFill(0xffffff)
		graphics.drawRect(0,100, 100,100);
		graphics.x = 50;
		graphics.tint = 0xff0000;
		//graphics.updateTransform();

    	world = game.add.group();

		textStatus = game.add.text(originalWidth / 2, 20, "Waiting for stage", {
		        font: "65px Arial",
		        fill: "#00ff44",
		        align: "center"
		    });
	    textStatus.anchor.set(0.5, 0);
	    world.add(textStatus);
		
		tbxStageId = $('<input type="tel">').appendTo('#container');
		tbxStageId.css({
			'position': 'absolute',
			'left': (game.world.centerX - tbxStageId.width() / 2) + 'px',
			'top': 130 + 'px',
		})
		.keyup(function(key){
			if(event.which == 13){
				handleJoinStageClicked();
			}
		})
		.focus();

		buttons = game.add.group();
		btnJoinStage = common.drawButton('Join stage', originalWidth / 2, originalHeight / 2 - 100, handleJoinStageClicked);
		buttons.add(btnJoinStage);
		buttons.add(btnJoinStage.text);
		btnBecomeStage = common.drawButton('Become a stage', originalWidth / 2, originalHeight / 2, handleBecomeStageClicked, true);
		buttons.add(btnBecomeStage);
		buttons.add(btnBecomeStage.text);
		btnTestPlayer = common.drawButton('Test player', originalWidth / 2, originalHeight / 2 + 100, handleTestingPlayerClicked, true);
		buttons.add(btnTestPlayer);
		buttons.add(btnTestPlayer.text);
		btnTestStage = common.drawButton('Test stage', originalWidth / 2, originalHeight / 2 + 200, handleTestingStageClicked, true);
		buttons.add(btnTestStage);
		buttons.add(btnTestStage.text);

		btnScale = common.drawButton('Test scale', originalWidth / 2, originalHeight / 2 + 300, handleScaleClicked, true);
		buttons.add(btnScale);
		buttons.add(btnScale.text);
		world.add(buttons);

		btnReady = common.drawButton('Not Ready', originalWidth / 2, originalHeight / 2, handleReadyClicked);
		btnReady.kill();
		btnLeave = common.drawButton('Leave', originalWidth / 2, originalHeight / 2 + 100);
		btnLeave.kill();

	}

	function toggleButtons(on){
		if(on) {
			tbxStageId.show();
			buttons.callAll('revive');
		}
		else {
			tbxStageId.hide();
			tbxStageId.blur();
			buttons.callAll('kill');
		}
	}

	function toggleLobby(on) {
		if(on){
			btnReady.revive();
			btnLeave.revive();
		} else {
			btnReady.kill();
			btnLeave.kill();
		}
	}

	// gui handlers

	function handleBecomeStageClicked(){
		toggleButtons(false);
		textStatus.setText('Becoming a stage');
		game.state.start('lobby');
	}

	function handleTestingPlayerClicked(){
		// mockup
		player = {
			name: 'Cow',
			game: {
				boardCount: 3,
				library: [],
				hand: [],
			}
		}
		for(var i = 0; i < 30; i++){
			player.game.library.push(_.random(0,9));
		}
		// set test
		textStatus.setText('Testing player');
		config.isTest = true;
		setTimeout(function(){
			game.state.start('player');
		}, 1000);
	}

	function handleTestingStageClicked(){
		stage = {
			game: {
				boardCount: 3,
				boards: [],
			}
		}
		for(var i = 0; i < stage.game.boardCount; i++){
			stage.game.boards[i] = {
				current: _.random(0, 9),
				previous: [],
			}
		}
		config.isTest = true;
		textStatus.setText('Testing stage');
		setTimeout(function(){
			game.state.start('stage');
		}, 1000)
	}

	function handleJoinStageClicked(){
		prompt("Enter a Value","0");
		if(tbxStageId.val()){
			toggleButtons(false);
			socket.emit('speed.player.join', { id: tbxStageId.val() });
		}
		else {
			textStatus.setText('Select stage first');
		}
	}

	function handleReadyClicked(){
		isReady = !isReady;
		socket.emit('speed.player.ready', { isReady: isReady });
		if(isReady){
			btnReady.text.setText('Ready');
		}
		else{
			btnReady.text.setText('Not Ready');
		}
	}

	function handleLeaveClicked(){
		socket.emit('speed.player.leave');
		toggleLobby(false);
	}

	function handleScaleClicked(){

		buttons.scale.set(game.width / 960, game.height / 640);
	}

	// socket handlers

	function handleJoin(data){
		console.log('speed.player.join', JSON.stringify(data))
		textStatus.setText('connected to stage ' + data.stage.id);
		btnLeave.events.onInputDown.addOnce(handleLeaveClicked);
		isReady = false;
		toggleLobby(true);
	}

	function handleLeave(data){
		textStatus.setText('Declined: ' + data.reason);
		toggleButtons(true);
		toggleLobby(false);
	}

	function handleLoad(data){
		player = {
			game: data.game,
		};
		game.state.start('player');
	}

	// debug 

	function debugLatency(){
		textLatency = game.add.text(20, game.world.height - 100, version + ' : none', {
	        font: "40px Arial",
	        fill: "#00ff44",
	        align: "center"
	    });
		ping();
	}

	function ping(){
		var time = Date.now();
		socket.emit('common.ping', null, function(){
			if(game.state.current != 'main'){
				return;
			}
			var delta = (Date.now() - time);
			textLatency.setText(version + ' : ' + delta);
			setTimeout(ping, 1000);
		});
	}

	mainState = {

		preload: function() {
		},

		create: function(){

			drawGui();

			socket.on('speed.player.join', handleJoin);
			socket.on('speed.player.leave', handleLeave);
			socket.on('speed.player.load', handleLoad);

			debugLatency();
		},

		update: function(){
			if(++counter % 2 === 0){
			}
		},

		render: function(){
			game.debug.cameraInfo(game.camera, 32, 32);
            game.debug.inputInfo(32, 130);

		},

		shutdown: function(){
			tbxStageId.remove();

			socket.off('speed.player.join');
			socket.off('speed.player.leave');
			socket.off('speed.player.load');
		},

		resize: function (width, height) {
	        //  This could be handy if you need to do any extra processing if the game resizes.
	        //  A resize could happen if for example swapping orientation on a device.
	        console.log('gameResized');

    	},

	}

})();