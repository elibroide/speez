// stage.js

var lobbyState;

(function(){

	// data
	var startingTimeout;

	// gui
	var textStatus;
	var textData;
	var textPlayers;
	var btnBoardsCount;

	// Various

	function updatePlayersList(){
		textPlayers.text = 'Players list: \n';
		_.each(stage.players, function(value, key, list){
			textPlayers.text += value.id + ': ' + value.name + ' ' + value.isReady + '\n';
		});
	}

	function isAbleToPlay(){
		return _.size(stage.players) > 0 && _.every(stage.players, function(item){ return item.isReady; });
	}

	function startTimeout(){
		textStatus = game.add.text(game.world.centerX, game.world.centerY, "Starting the game", {
	        font: "65px Arial",
	        fill: "#cc0000",
	        align: "center"
	    });
	    textStatus.anchor.set(0.5, 0.5);
		startingTimeout = setTimeout(function(){
			// start game
			socket.emit('speed.stage.load');
		}, 3000);
	}

	function resetTimeout(){
		if(startingTimeout){
			textStatus.destroy();
			clearTimeout(startingTimeout);
			startingTimeout = null;
		}
	}

	function drawGui(){
		btnBoardsCount = common.drawButton('Boards Count: ' + stage.game.boardCount, game.world.centerX, game.world.centerX, handleBoardsCountClick);

		textData = game.add.text(game.world.centerX, game.world.centerY - 50, 'id: ' + stage.id, {
	        font: "40px Arial",
	        fill: "#00ff44",
	        align: "center"
	    });
	    textData.anchor.set(0.5);

		textPlayers = game.add.text(50, 50, 'Players list:', {
	        font: "40px Arial",
	        fill: "#00ff44",
	        align: "center"
	    });
	}

	// buttons handlers

	function handleBoardsCountClick(){
		stage.game.boardCount += 1;
		if(stage.game.boardCount > 4){
			stage.game.boardCount = 2;
		}
		btnBoardsCount.text.setText( 'Boards Count: ' + stage.game.boardCount);
	}

	function handleStartGameClick(){
        game.state.start('stage');
	}

	// socket handlers

	function handleIdentify(data){
		stage = data.stage;
		drawGui();
	}

	function handleJoin(data){
		console.log('speed.stage.join ' + JSON.stringify(data))

		stage.players[data.player.id] = data.player;
		updatePlayersList();
	}

	function handleLeave(data){
		console.log('speed.stage.leave ' + JSON.stringify(data))

		delete stage.players[data.id];
		updatePlayersList();
		if(!isAbleToPlay()) {
			resetTimeout();
		}
	}

	function handleReady(data) {
		stage.players[data.id].isReady = data.isReady;
		updatePlayersList();
		if(!data.isReady){
			resetTimeout();
			return;
		}
		if(isAbleToPlay()){
			startTimeout();
		}
	}

	function handleLoad(data) {
		stage.game = data.game;
		game.state.start('stage');
	}

	lobbyState = {

		preload: function(){
		},

		create: function(){

			socket.on('speed.stage.identify', handleIdentify);
			socket.on('speed.stage.join', handleJoin);
			socket.on('speed.stage.leave', handleLeave);
			socket.on('speed.stage.ready', handleReady);
			socket.on('speed.stage.load', handleLoad);
			socket.emit('speed.stage.identify')
		},

		update: function(){

		},

		render: function(){

		},

		shutdown: function(){
			socket.off('speed.stage.join');
			socket.off('speed.stage.leave');
			socket.off('speed.stage.ready');
			socket.off('speed.stage.load');
		},

	}

})();