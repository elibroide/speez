// player.js

var playerState;

(function(){

	var topBarY;
	var fullY;
	var middleY;
	var leftX;
	var rightX;

	var boards;

	var hand = [];
	var inputCurrentX;
	var inputCurrentY;
	var heldCard;
	var putCard;

	// top menu
	var topMenuBar;
	var btnPause;
	var textName;

	// input
	var isClickable;

	function tweenTint(obj, startColor, endColor, time) {
	    // create an object to tween with our step value at 0
	    var colorBlend = {step: 0};

	    // create the tween on this object and tween its step property to 100
	    var colorTween = game.add.tween(colorBlend).to({step: 100}, time);
	    
	    // run the interpolateColor function every time the tween updates, feeding it the
	    // updated value of our tween each time, and set the result as our tint
	    colorTween.onUpdateCallback(function() {
	      obj.tint = Phaser.Color.interpolateColor(startColor, endColor, 100, colorBlend.step);   
	    });
	    
	    // set the object to the start color straight away
	    obj.tint = startColor;    
	    
	    // start the tween
	    colorTween.start();
	}

	function drawTopBar(){
		topMenuBar = game.add.sprite(0, 0, 'blank');
		topMenuBar.scale.set(game.world.width, topBarY);
		topMenuBar.tint = 0xffff00;

		textName = game.add.text(game.world.centerX, 50, player.name + ' ' + player.game.library.length, {
	        font: "20px Arial",
	        fill: "#ff0044",
	        align: "center"
	    });
	    textName.anchor.set(0.5, 0.5);
	}

	function drawBoards(){
		var boardsWidth = 0.215;
		topBarY = 100;
		leftX = game.world.width * boardsWidth;
		rightX = game.world.width - leftX;
		fullY = game.world.height - topBarY
		middleY = fullY / 2;

		

		switch(player.game.boardCount){
			case 2:
				boards[0] = game.add.tileSprite(0, topBarY, leftX, fullY, 'colors', colors.BOARD1);
				boards[1] = game.add.tileSprite(rightX, topBarY, leftX, fullY, 'colors', colors.BOARD2);
				break;
			case 3:
				boards[0] = game.add.tileSprite(0, topBarY, leftX, middleY, 'colors', colors.BOARD1);
				boards[1] = game.add.tileSprite(rightX, topBarY, leftX, fullY, 'colors', colors.BOARD2);
				boards[2] = game.add.tileSprite(0, middleY + topBarY, leftX, middleY, 'colors', colors.BOARD3);
				break;
			case 4:
				boards[0] = game.add.tileSprite(0, topBarY, leftX, middleY, 'colors', colors.BOARD1);
				boards[1] = game.add.tileSprite(rightX, topBarY, leftX, middleY, 'colors', colors.BOARD2);
				boards[2] = game.add.tileSprite(0, middleY + topBarY, leftX, middleY, 'colors', colors.BOARD3);
				boards[3] = game.add.tileSprite(rightX, middleY + topBarY, leftX, middleY, 'colors', colors.BOARD4);
				break
		}
	}

	function checkIfInBounds(x, y){
		if(y < topBarY){
			return -1;
		}
		if(x < leftX){
			if(player.game.boardCount > 2 && y > topBarY + middleY) {
				return 2;
			}
			else { 
				return 0;
			}
		} else if(x > rightX){
			if(player.game.boardCount > 3 && y > topBarY + middleY) {
				return 3;
			} else {
				return 1;
			}
		}
		else{
			return -1;
		}
	}

	function drawCard(index){
		if(player.game.library.length == 0){
			console.log('card cannot be drawn: library has no cards');
			return;
		}
		var card = player.game.library.pop();
		player.game.hand[index] = card;

		var sprCard = game.add.sprite(game.world.centerX, topBarY + 86 + index * 172, 'blank');
		sprCard.scale.set(rightX-leftX, 172);
		sprCard.tint = 0x000000;
		sprCard.anchor.set(0.5, 0.5);
	    sprCard.card = card;
		sprCard.index = index;
		sprCard.inputEnabled = true;
		sprCard.originalX = sprCard.x;
	    sprCard.originalY = sprCard.y;

		sprCard.text = game.add.text(sprCard.x, sprCard.y, card.toString(), {
	        font: "65px Arial",
	        fill: "#ff0044",
	        align: "center"
	    });
	    sprCard.text.anchor.set(0.5, 0.5);

	    sprCard.alpha = 0;
	    sprCard.text.alpha = 0;
	    TweenMax.to([sprCard, sprCard.text], 0.25, { alpha: 1, ease: Sine.easeOut })

	    sprCard.events.onKilled.add(function(){
	    	sprCard.text.setText('');
	    });
	    sprCard.events.onRevived.add(function(){
	    	sprCard.text.setText(sprCard.card);
	    });

	    hand[index] = sprCard;
	}

	function bindCard(index){
		if(!hand[index]){
			console.log('cannot bind card: no card in index ' + index)
			return;
		}
		hand[index].events.onInputDown.add(handleCardInputDown, this);
	}

	function handleCardInputDown(spr, pointer){
		if(!isClickable){
			return;
		}
		isClickable = false;
		inputCurrentX = pointer.x;
		inputCurrentY = pointer.y;
		tweenTint(spr, spr.tint, 0xffffff, 100);
		spr.bringToTop()
		game.world.bringToTop(spr.text);
    	heldCard = spr;
    	game.input.onUp.addOnce(handleCardInputUp, this);
	}

	function handleCardInputUp(pointer) {
		var boardId = checkIfInBounds(pointer.x, pointer.y);
		if(boardId != -1){
			heldCard.events.onInputDown.removeAll();
			putCard = heldCard;
			putCard.boardId = boardId;
			animateCardDisappear(putCard, boardId);
			if(config.isTest){
				setTimeout(function(){
					handleCard({confirm: boardId == 1});
				}, 1);
			}
			else{
    			socket.emit('speed.player.card', { boardId: boardId, handId: putCard.index });
    		}
		}
		else {
			tweenTint(heldCard, 0xffffff, 0x000000, 100);
			isClickable = true;
			animateCardReturn(heldCard);
		}
    	heldCard = null;
	}

	function animateCardReturn(sprCard){
		var timeline = new TimelineMax({ paused: true });
		timeline.to( [sprCard, sprCard.text], 0.2, { x: sprCard.originalX, y: sprCard.originalY } );
		timeline.play();
		sprCard.timeline = timeline;
	}

	function animateCardDisappear(sprCard, boardId){
		var targetY;
		if(boardId == 0 || boardId == 1){
			targetY = 0;
		}
		else{
			targetY = game.world.height;
		}
		var timeline = new TimelineMax({ paused: true});
		timeline.to( [sprCard, sprCard.text], 0.2, { y: targetY, alpha: 0 } );
		timeline.to( sprCard.scale, 0.2, { x: 0, y: 0 }, 0);
		timeline.play();
		sprCard.timeline = timeline;
	}

	function animateError(){
		var cardsInHand = _.filter(hand, function(item){ return item });
		var timeline = new TimelineMax({ repeat: 1, onComplete: function(){
				isClickable = true;
			}
		});
		timeline.to(cardsInHand, 0.06, { angle: -3, ease: Back.easeOut });
		timeline.to(cardsInHand, 0.12, { angle: 6, ease: Back.easeOut });
		timeline.to(cardsInHand, 0.05, { angle: 0, ease: Linear.easeNone });
		timeline.play();
	}

	function bindAllCards(){
		for(var i = 0; i < hand.length; i++){
			bindCard(i);
		}
	}

	function unbindAllCards(){
		for(var i = 0; i < hand.length; i++){
			hand[i].events.onInputDown.removeAll();
		}
	}

	// handling gui

	function handleSpeedyClicked(){
		if(config.isTest){
			setTimeout(function(){
				handleSpeedy();
			}, 500);
			return;
		}
		socket.emit('speed.player.speedy');
	}

	// handling socket

	function handleStart(){
		bindAllCards();
	}

	function handleCard(data){
		var boardId = putCard.boardId;
		var index = putCard.index;
		var card = putCard;
		putCard = null;
		if(data.confirm){
			isClickable = true;
			if(card.timeline.isActive()){
				card.timeline.vars.onComplete = function(){
					card.destroy();
					card.text.destroy();
				};
			}
			else{
				card.destroy();
				card.text.destroy();
			}
			hand[index] = null;
			drawCard(index);
			bindCard(index);
			
		} else{
			if(card.timeline.isActive()){
				card.timeline.kill();
			}
			card.x = card.originalX;
			card.y = card.originalY;
			card.text.x = card.x;
			card.text.y = card.y;
			card.alpha = 1;
			card.text.alpha = 1;
			card.scale.set(1, 1);
			card.tint = 0x000000;
			bindCard(card.index);
			animateError();
		}
	}

	playerState = {

		preload: function(){
		},

		create: function(){
			
			game.stage.backgroundColor = 0x515151;
			
			isClickable = true;
			hand = [];
			boards = [];
			drawBoards();
			for(var i=0;i<5;i++) {
				drawCard(i);
			}
			drawTopBar();

			socket.on('speed.player.start', handleStart);
			socket.on('speed.player.card', handleCard);

			if(config.isTest){
				handleStart();
				return;
			}
			socket.emit('speed.player.loaded');
		},

		update: function(){
			if(heldCard){
				var deltaX = game.input.activePointer.x - inputCurrentX;
				var deltaY = game.input.activePointer.y - inputCurrentY;
				heldCard.x += deltaX;
				heldCard.y += deltaY; 
				heldCard.text.x += deltaX;
				heldCard.text.y += deltaY;

				inputCurrentX = game.input.activePointer.x;
				inputCurrentY = game.input.activePointer.y;
			}
		},

		render: function(){
		},
	}
})();
